<?php
// Automaticly getting the home page from the public folder
$page = "home";
include "public/{$page}.php"; ?>