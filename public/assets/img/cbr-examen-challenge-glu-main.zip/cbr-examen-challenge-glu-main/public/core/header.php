<!--Create the header without the header tags-->
<p>Header</p>