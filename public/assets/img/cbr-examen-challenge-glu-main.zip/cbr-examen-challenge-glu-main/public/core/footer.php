<!--Create the footer without the footer tags-->
<p>Footer</p>